/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

export const SCREEN_READER_USER_PREFIX = 'User: ';

export const SCREEN_READER_MODEL_PREFIX = 'Model: ';

export const SCREEN_READER_LOADING = 'loading';

export const SCREEN_READER_RESPONDING = 'responding';
